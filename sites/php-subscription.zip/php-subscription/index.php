<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>ePay - PHP example of ePay subscriptions</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<h1>PHP example of ePay subscriptions</h1>

This example code will show you how to make subscriptions with ePay. On the accept page you will be able to make new payments based on the subscription.
<br /><br />
The first page (<i>payment.php</i>) will show you how to open up the ePay Standard Payment Window to make payment and add subscriber.
<br /><br />
The second page (<i>accept.php</i>) will show you how to setup a payment receipt page with information of the payment made. On this page you will be able to handle the payment and the subscription.
<br /><br />
(<i>callback.php</i>) is called by ePay when the payment is made. <b>Tip!</b> Change the $email variable in the callback.php to receive an e-mail when the payment is made.
<br /><br />
(<i>epaysoap.php</i>) contains functions used by handle_payment.php to call the ePay Webservice (API).
<br /><br />
(<i>handle_payment.php</i>) is an example of using the ePay Webservice to capture, credit and delete a transaction. This file is included in accept.php. <b>Remember!</b> You need to change merchantnumber in line 4.
<br /><br />
(<i>handle_subscription.php</i>) handles when capture, credit, delete or authorize transactions.
<br /><br />
<div class="notice">
<b>Notice!</b><br />
In order to test you need a test merchant number. To obtain a test merchant number please sign up for a <b>FREE</b> ePay test account here: <a href="http://www.epay.dk/main/signup.asp" target="_blank">Get ePay test account</a>. 
<br />
When you have obtained this test account you can in this programming example enter the test merchant number in the field named <i>merchantnumber</i> on the next page.
<br /><br />
<b>Remember!</b><br />
For this example to work you must have an ePay Business subscription.
</div>
<br /><br />
To get started just click this link: <a href="payment.php">Start subscription payment</a>.<br /><br />

<br /><br />
<b>Support</b><br />
For support please contact us at one of the following mails:
<table cellspacing="0" cellpadding="3">
	<tr>
		<td>Danish</td>
		<td>
			<a href="mailto:support@epay.dk">support@epay.dk</a>
		</td>
	</tr>
	<tr>
		<td>Swedish</td>
		<td>
			<a href="mailto:support@epay.se">support@epay.se</a>
		</td>
	</tr>		
	<tr>
		<td>English</td>
		<td>
			<a href="mailto:support@epay.eu">support@epay.eu</a>
		</td>
	</tr>
</table>
</body>
</html>