<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>ePay - PHP example</title>
	<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<h1>Handle subscription</h1>
<?php
//Get the class
require_once("epaysoap.php");
//Access the webservice
$epay = new EpaySoap();

//Change the merchant number below to make this example work
$merchantnumber = 99999999;

//Get action
if(isset($_GET['mode'])){
	$mode = $_GET['mode'];
	
	//Select mode
	switch($mode){
		case 1: //Capture
			$return = $epay->capture($merchantnumber, $_GET['tid'], $_GET['amount']);
		break;
		case 2: //Credit
			$return = $epay->credit($merchantnumber, $_GET['tid'], $_GET['amount']);
		break;
		case 3: //Delete
			$return = $epay->delete($merchantnumber, $_GET['tid']);
		break;
		case 4: //New
			$return = $epay->authorize($merchantnumber, $_POST['subscriptionid'], $_POST['orderid'], $_POST['amount'], $_POST['currency'], $_POST['instantcapture']);
		break;
	}
	
	//If response from Webservice is OK then return to referer.
	if($return['epayresponse'] == -1){
		
		header("Location: ".$_SERVER['HTTP_REFERER']);
		
	}else{ //If errors
	
		echo "<div class=\"notice\">";
		
			if($return['epayresponse'] <> -1){
				echo "ePay: ".$epay->getEpayError($merchantnumber, $return['epayresponse']);
			}
			
			if($return['pbsResponse'] <> -1 and strlen($return['pbsResponse']) > 0){
				echo "<br />PBS: ".$epay->getPbsError($merchantnumber, $return['pbsResponse']);
			}
			
			if($return['pbsresponse'] <> -1 and strlen($return['pbsresponse']) > 0){
				echo "<br />PBS: ".$epay->getPbsError($merchantnumber, $return['pbsresponse']);
			}
			
		echo "</div><br />";

	}
	
	
 }
?>
<a href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Go back</a>
</body>
</html>