<h1>Remote Handle Payment (API)</h1>
<?php
//Get the class
require_once("epaysoap.php");
//Access the webservice
$epay = new EpaySoap();

//Change the merchant number below to make this example work
$merchantnumber = 99999999;

//Function to get the current URL
function curPageURL() {
	$pageURL = 'http';
	if (@$_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
	$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} else {
	$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	
	$replace = "&mode=".$_GET['mode'];
	
	$pageURL = str_replace($replace,"",$pageURL);
	
	return $pageURL;
}

?>

<?php
$subscription = $epay->getsubscriptions($merchantnumber, $_GET['subscriptionid']);


	if(count($subscription['subscriptionAry']['SubscriptionInformationType']['transactionList']) == 1){
		$subscriptionTransactions = $subscription['subscriptionAry']['SubscriptionInformationType']['transactionList']['TransactionInformationType'];
	}else{
		$subscriptionTransactions = $subscription['subscriptionAry']['SubscriptionInformationType']['transactionList'];
	}
		

	foreach($subscriptionTransactions as &$transaction){
			
			
			
			//Check the result
			//if($transaction['gettransactionResult'] == 'true'){
				
					//Get the transaction history
					$history = $transaction['history']['TransactionHistoryInfo'];
					
						
					
					if(!array_key_exists(0, $history)){
						$history = array($history);
					}
		
					if(is_array($history)){
						asort($history);
					echo "<table cellspacing=\"0\" cellpadding=\"3\" style=\"width: 800px;\">";
					foreach($history as $value){
						
					?>
							<tr>
								<td>
									<?php echo $transaction['transactionid']; ?>
								</td>
								<td>
									<?php echo date("Y-m-d H:i", strtotime($value['created'])); ?>
								</td>
								<td>	
									<?php echo $value['eventMsg']; ?>
								</td>
							</tr>
					<?php
						}
						echo "</table>";
					}
					
				echo "<br />You can now handle the payment by clicking here: <a href=\"handle_subscription.php?mode=1&tid=".$transaction['transactionid'] ."&amount=".$transaction['authamount'] ."\">Capture</a> - <a href=\"handle_subscription.php?mode=2&tid=".$transaction['transactionid'] ."&amount=".$transaction['authamount'] ."\">Credit</a> - <a href=\"handle_subscription.php?mode=3&tid=".$transaction['transactionid'] ."\">Delete</a><br /><br /><br />";
			//}else{
				//If not able to connect to the webservice
				//echo "ePay Error:". $transaction['epayresponse'];	
			//}
		$i++;
	}
?>


<h1>New subscription payment with API</h1>
<form action="handle_subscription.php?mode=4" method="post">

<table cellspacing="0" cellpadding="3" style="width: 800px;">
		<tr>
			<td>Amount:</td>
			<td>
				<input type="text" name="amount" value="100" style="width: 200px;" />
			</td>
			<td>
				The amount in minor units. 1 DKK = 100.
			</td>
		</tr>
		<tr>
			<td>Currency:</td>
			<td>
				<select name="currency" style="width: 200px;">
					<option value="208">DKK (208)</option>
					<option value="978">EUR (978)</option>
					<option value="840">USD (840)</option>
					<option value="578">NOK (578)</option>
					<option value="752">SEK (752)</option>
					<option value="826">GBP (826)</option>
					<option value="036">AUD (036)</option>
				</select>
			</td>
			<td>
				The currency number which the amount is provided in. A full list of supported currencies is available in the ePay administration <b>Support</b> - <b>Currency codes</b>: 
			</td>
		</tr>
		<tr>
			<td>OrderID:</td>
			<td>
				<input type="text" name="orderid" value="" style="width: 200px;" />
			</td>
			<td>
				This is your reference for the payment. By leaving this blank we'll generate a unique order id for you.
			</td>
		</tr>
		<tr>
			<td>Subscription ID:</td>
			<td><?php echo $_GET['subscriptionid'] ?><input type="hidden" name="subscriptionid" value="<?php echo $_GET['subscriptionid'] ?>" /></td>
			<td>
				The subscription which the payment will be autorized
			</td>
		</tr>
		<tr>
			<td>Capturing:</td>
			<td>
				<select name="instantcapture">
					<option value="0">Capture the payment manually</option>
					<option value="1">Is captured instantly</option>
				</select>
			</td>
			<td>
				Capturing of the payment
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td colspan="2"><input type="submit" value="Autorize amount" class="button" style="width: 200px;"></td>
		</tr>
	</table>
</form>

